import boto3
import pandas as pd
import time
import awswrangler as wr
import requests
from botocore.client import ClientError
import concurrent.futures 
from itertools import repeat

s3_client = boto3.client('s3')
dynamo_client = boto3.client('dynamodb',region_name="ap-northeast-1")

timestamp = int(time.time()*1000) - 60000

symbol_list = wr.s3.read_json(path='s3://bucket-phrase-1/top_cap.json')[0].values.tolist()[0:10]
interval = ['15m','1h','4h','1d']

glue_catalog_db="demo_catalog_db"
glue_catalog_tb="demo_catalog_tb"
parquet_s3_path = "s3://bucket-phrase-2"
bucket = 'bucket-phrase-2'
dynamodb_tb = "demo-dynamodb_tb"
my_session = boto3.Session(region_name="ap-northeast-1")

# First update symbols list and timeframe to dynamodb for later backtesting analysis
for symbol in symbol_list:
    items=dynamo_client.get_item(
        TableName=dynamodb_tb,
        Key={
            'Symbol':{'S':symbol},
            'TimeFrame':{'S':'15m'}
    })
    if 'Item' not in items:
        for timeframe in interval:
            try:
                wr.dynamodb.put_items(
                items=[{
                    'Symbol': symbol, 
                    'TimeFrame':timeframe,
                }],
                table_name=dynamodb_tb,
                boto3_session = my_session
                )
            except ClientError as e:
                print (e)


# Define partitions key and columns for Glue Job
partitions_types = {
    'par': 'string',
}
columns_types = {
    'Time': 'bigint',
    'Open': 'double',
    'High': 'double',
    'Low': 'double',
    'Close': 'double',
    'Volume': 'double',
    'Quote_asset_volume': 'double',
    'Number_of_trades': 'double',
    'Taker_buy_base_asset_volume': 'double',
    'Taker_buy_quote_asset_volume': 'double',
    'Interval':'string'
}
columns = list(columns_types.keys())
base_url = "https://api.binance.com/api/v3/klines"

def interval_to_milliseconds(interval):
    seconds_per_unit = {
        "m": 60,
        "h": 60 * 60,
        "d": 24 * 60 * 60,
        "w": 7 * 24 * 60 * 60,
    }
    unix_ts = int(interval[:-1]) * seconds_per_unit[interval[-1]] * 1000
    return unix_ts

base_url = "https://api.binance.com/api/v3/klines"

def data_request(symbol,interval,start,end, limit):
    data=dict()
    data['symbol'] = symbol
    data['interval'] = interval
    data['startTime'] = start
    data['endTime'] = end
    data['limit'] = limit
    response = requests.get(base_url, params=data).json()
    return response

def get_earliest_valid_timestamp(symbol, interval):
    kline = data_request(symbol,interval,0,timestamp, limit = 1)
    return kline[0][0]

def get_df(symbol,interval,start,end, limit):
    start_ts = start
    if start_ts is not None:
        first_valid_ts = get_earliest_valid_timestamp(symbol, interval)
        start_ts = max(start_ts, first_valid_ts)
    end_ts = end
    idx = 0
    timeframe = interval_to_milliseconds(interval=interval)
    klines = []
    while True:
        # fetch the klines from start_ts up to max 1000 entries or the end_ts if set
        temp_data = data_request(symbol,interval,start_ts,end_ts,limit)
        # append this loops data to our output data
        if temp_data:
            klines += temp_data

        # handle the case where exactly the limit amount of data was returned last loop
        # check if we received less than the required limit and exit the loop
        if not len(temp_data) or len(temp_data) < limit:
            # exit the while loop
            break

        # increment next call by timeframe
        start_ts = temp_data[-1][0] + timeframe

        # exit loop if we reached end_ts before reaching <limit> klines
        if end_ts and start_ts >= end_ts:
            break

        # sleep after every 3rd call to be kind to the API
        idx += 1
        if idx % 3 == 0:
            time.sleep(1)
            
    # Clean dataframe
    df = pd.DataFrame(klines)
    df = df.iloc[:,:11]
    df.drop(6, axis=1, inplace=True)
    df.columns = columns[0:10]
    float_columns = [i for i in columns if i not in ['Time','Close_time','Interval']]
    df[float_columns] = df[float_columns].astype(float)
    df['par'] = symbol
    df['interval'] = interval
    return df

def push_parquet(symbol):
    result = s3_client.list_objects_v2(Bucket=bucket, Prefix =f'par={symbol}')
    my_session = boto3.Session(region_name="ap-northeast-1")
    if 'Contents' not in result:
        # Ingest entire historical price data for any symbol that is not available in datalake
        # Concat dataframe of all timeframe
        try:
            first_idx = True 
            for i in interval:
                if first_idx:
                    df = get_df(symbol, i, 0, timestamp, 1000)
                    first_idx = False
                else: 
                    df = pd.concat([df, get_df(symbol, i, 0, timestamp, 1000)])

            # Upload new data to s3 datalake 
            response = wr.s3.to_parquet(
                df = df,
                path = parquet_s3_path,
                index = False,
                filename_prefix = str(timestamp//60000 * 60000),
                dataset = True,
                database = glue_catalog_db,
                table = glue_catalog_tb,
                partition_cols = ["par"],
                schema_evolution=False,
                mode="append",
                boto3_session = my_session,
            )
            print (f'Updated {symbol} to database')
        except ClientError as e:
            print (f"Cannot upload  {symbol} klines to database, error: {e}")
            pass
    else:
        # Only update new historical price data for all symbols in the datalake
        start_time = int(result['Contents'][-1]['Key'].replace('/','.').split('.')[1][0:13]) + 60000
        print (start_time)
        # Concat dataframe of all timeframe
        try:
            first_idx = True               
            for i in interval:
                if (timestamp - start_time) > interval_to_milliseconds(i):
                    if first_idx:
                        df = get_df(symbol, i, start_time, timestamp, 1000)
                        first_idx = False
                    else: 
                        df = pd.concat([df, get_df(symbol, i, start_time, timestamp, 1000)])
                else:
                    print (f"New data is not available yet for {symbol} {i}!!")
                    continue

            # Upload new data to s3 datalake
            response = wr.s3.to_parquet(
                df = df,
                path = parquet_s3_path,
                index = False,
                filename_prefix = str(timestamp//60000 * 60000),
                dataset = True,
                database = glue_catalog_db,
                table = glue_catalog_tb,
                partition_cols = ["par"],
                schema_evolution=False,
                mode="append",
                boto3_session = my_session,
            )
            print (f'Updated {symbol} to database')

        except ClientError as e:
            print (f"Cannot upload {symbol} to database, error: {e}")
            pass


def handler(event,context):
    # Create glue data catalog table if it's not exist yet
    try:
        check_table = wr.catalog.table(
            database=glue_catalog_db, 
            table=glue_catalog_tb,
            boto3_session = boto3.Session(region_name="ap-northeast-1")
            )
        print ('Table is available') 
    except:
        wr.catalog.create_parquet_table(
            database=glue_catalog_db,
            table=glue_catalog_tb,
            path=parquet_s3_path,
            columns_types=columns_types,
            partitions_types = partitions_types,
            compression='snappy',
            parameters = {'project': 'crypto_trading_system'},
            boto3_session = boto3.Session(region_name="ap-northeast-1")
            )
        print ('Create a new table')   

    # Perform ingestion for historical price data of cryptocurrencies
    with concurrent.futures.ProcessPoolExecutor() as executor:
        executor.map(push_parquet,symbol_list)