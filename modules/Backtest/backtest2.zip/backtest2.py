import boto3 
from botocore.client import ClientError
import numpy as np
import awswrangler as wr
import concurrent.futures
import pandas as pd
pd.set_option('mode.chained_assignment', None)

dynamodb_tb = "demo-dynamodb_tb"
my_session = boto3.Session(region_name="ap-northeast-1")
s3_client = boto3.client('s3')
dynamo_client = boto3.client('dynamodb',region_name="ap-northeast-1")

symbol_list = wr.s3.read_json(path='s3://bucket-phrase-1/top_cap.json')[0].values.tolist()[5:10]
interval = ['15m','1h','4h','1d']

def backtest(df,symbol,timeframe):
    ## Buy condition 
    # 1. Close price > EMA150
    ema_buy = df['close'] > df['EMA150'] 

    # 2. RSI > 50
    rsi_buy = df['RSI'] > 50

    # 3. MACD_line cross Signal_line from downside to upside
    is_MACD_above_signal = df['MACD_line'] > df['Signal_line']
    is_MACD_cross_signal = is_MACD_above_signal.diff()
    macd_buy = np.where(is_MACD_above_signal & (is_MACD_cross_signal==1), True, False)

    # Combine sell conditions: 1,2,3 to one colume: buy_signal (all conditions must be satisfied to place buy order)
    df['buy_signal'] = np.where(((ema_buy) & (rsi_buy) & (macd_buy)) , 1, 0)

    ## Sell condition 
    # 1. Reach stop loss or reach take profit
    stop_loss = 0.02
    take_profit = 0.04

    # 2. Close price < EMA150
    ema_sell = df['close'] < df['EMA150'] 

    # 3. RSI < 50
    rsi_sell = df['RSI'] < 50

    # 3. MACD_line cross Signal_line from upside to downside
    is_MACD_under_signal = df['MACD_line'] < df['Signal_line']
    is_MACD_cross_signal = is_MACD_under_signal.diff()
    macd_sell = np.where(is_MACD_under_signal & (is_MACD_cross_signal==1), True, False)

    # Combine sell conditions: 2,3,4 to one colume (only need 1 condition to place sell order)
    df['sell_signal'] = np.where(((ema_sell) | (rsi_sell) | (macd_sell)) , 1, 0)

    # Loop over dataframe to find buy signal = 1
    outcome = {}
    for i in range(len(df)):
        if df['buy_signal'].iloc[i] == 1:
            # Enter trade
            j = 1 # (rolling time window)
            in_position = True

            # Calculate loss price and take profit price after we enter trade
            stop_loss_price = df['close'].iloc[i] * (1 - stop_loss)
            take_profit_price = df['close'].iloc[i] * (1 + take_profit)   

            # Follow up the trade until sell signal = 1 or hit stop loss (profit)
            while in_position and (i+j) < len(df):
                if df['low'].iloc[i+j] <= stop_loss_price:
                    outcome[i+j] = 'SL'
                    df['sell_signal'].iloc[i+j]=1
                    in_position=False
                elif df.high.iloc[i+j] >= take_profit_price:
                    outcome[i+j] = 'TP'
                    df['sell_signal'].iloc[i+j]=1
                    in_position=False
                elif df['sell_signal'].iloc[i+j]==1:
                    if df['close'].iloc[i+j] <= df['close'].iloc[i]:
                        outcome[i+j] = 'SL'
                        in_position=False  
                    else:
                        outcome[i+j] = 'TP'
                        in_position=False
                j+=1 

    # Append outcome to dataframe
    df['outcome'] = 0
    for idx,value in outcome.items():
        df['outcome'].iloc[idx] = value
    df.set_index('time',inplace=True)

    # Create sorted dataframe contains only buy and sell rows
    summary = df[(df['buy_signal']==1) | ((df['sell_signal']==1) & (df['outcome']=='SL')) | ((df['sell_signal']==1) & (df['outcome']=='TP'))]

    # Crypto analysis
    summary['return'] = 'NaN'
    for i in range(len(summary)):
        if  i-1 >= 0 :
            if summary['outcome'].iloc[i]=='TP':
                summary['return'].iloc[i] = ((summary['close'].iloc[i]/summary['close'].iloc[i-1]) -1) 
            elif summary['outcome'].iloc[i]=='SL':
                summary['return'].iloc[i] = - (1-(summary['close'].iloc[i]/summary['close'].iloc[i-1]))         
            elif summary['outcome'].iloc[i]==0:
                summary['return'].iloc[i]='NaN'  
                
    returns = summary[['return']][summary['return'] != 'NaN'].squeeze()
    returns.index = pd.to_datetime(returns.index, format='%Y-%m-%d %H:%M:%S')
    if len(returns.index) != 0:
        # Return
        symbol_return = returns.sum()

        # Win rate
        trades = summary['outcome'].value_counts()
        if 'TP' not in trades:
            trades['TP'] = 0
        win_rate = (trades['TP']/(trades['TP']+trades['SL'])).round(3)

        # Risk (annualize volatility)
        periods = 365
        volatility = (np.std(returns) * np.sqrt(periods)).round(3)

        # Consecutive win,loss
        postive_return = returns > 0
        negative_return = returns < 0

        consecutive_win = (postive_return * (postive_return.groupby((postive_return != postive_return.shift(1)).cumsum()).cumcount() + 1)).max()
        consecutive_loss = (negative_return * (negative_return.groupby((negative_return != negative_return.shift(1)).cumsum()).cumcount() + 1)).max()

        # Skewness
        skewness = returns.skew()
        item = {      
            'Symbol': symbol, 
            'TimeFrame': timeframe,
            'Return': symbol_return,
            'Win_rate': win_rate,
            'Profitable_trades': trades['TP'],
            'Loss_trades': trades['SL'],
            "Consecutive_win": consecutive_win, 
            'Consecutive_loss': consecutive_loss,
            'Volatility': volatility,
            'Skewness': skewness
        }
    else:
        item = {      
            'Symbol': symbol, 
            'TimeFrame': timeframe,
            'Return': 0,
            'Win_rate': 0,
            'Profitable_trades': 0,
            'Loss_trades': 0,
            "Consecutive_win": 0, 
            'Consecutive_loss': 0,
            'Volatility': 0,
            'Skewness': 0
        }
    print (item)
    for i, j in item.items():
        item[i] =str(j)
    try:
        wr.dynamodb.put_items(
                items=[item],
                table_name=dynamodb_tb,
                boto3_session = boto3.Session(region_name="ap-northeast-1")
        )
    except ClientError as e:
        print (e)


def handler(event,context):
    for symbol in symbol_list:
        df = wr.timestream.query(
                sql=
                f"""
                    SELECT * FROM "demo-ts-db"."demo-ts-tb" 
                    WHERE par='{symbol}'
                    AND EMA150 != 'None'
                    ORDER BY time ASC
                """,
                boto3_session=my_session
            )
        dict = {'measure_value::double':'close'}
        df.rename(columns=dict,
                inplace=True)
        df.drop(columns = ['measure_name','par'], inplace = True)
        df.drop_duplicates(inplace=True)
        columns = list(df.columns)
        columns.remove('interval')
        columns.remove('time')
        df[columns] = df[columns].astype(float)
        for timeframe in interval:
            backtest(df[df['interval']==timeframe],symbol,timeframe)
